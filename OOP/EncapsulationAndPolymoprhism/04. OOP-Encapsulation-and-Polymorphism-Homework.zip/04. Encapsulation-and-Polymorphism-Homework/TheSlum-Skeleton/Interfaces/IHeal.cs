﻿namespace TheSlum.Interfaces
{
    public interface IHeal
    {
        int HealingPoints { get; set; }
    }
}
