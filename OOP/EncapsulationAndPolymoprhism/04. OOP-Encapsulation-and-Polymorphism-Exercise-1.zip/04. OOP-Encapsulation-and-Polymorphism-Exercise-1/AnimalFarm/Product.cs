﻿namespace AnimalFarm
{
    public class Product
    {
    }
}